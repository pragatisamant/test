//
//  Constants.swift
//  RebelTestPragati
//
//  Created by Pragati Samant on 20/07/19.
//  Copyright © 2019 Pragati. All rights reserved.
//

import Foundation
class Constants
{
    static let end_point = "http://makeup-api.herokuapp.com/api/v1/products.json"
    static let productTypes = [ProductType(title: "Blush", key: "blush"),ProductType(title: "Bronzer", key: "bronzer"),ProductType(title: "Eyebrow", key: "eyebrow"),ProductType(title: "Eyeliner", key: "eyeliner"),ProductType(title: "Eyeshadow", key: "eyeshadow"),ProductType(title: "Foundation", key: "foundation"),ProductType(title: "Lipliner", key: "lipliner"),ProductType(title: "Lipstick", key: "lipstick"),ProductType(title: "Mascara", key: "mascara"),ProductType(title: "Nail Polish", key: "nail_polish")]//["blush","bronzer","eyebrow","eyeliner","eyeshadow","foundation","lipliner","lipstick","mascara","nail_polish"]
}



