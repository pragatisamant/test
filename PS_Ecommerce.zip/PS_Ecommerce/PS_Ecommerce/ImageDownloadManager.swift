//
//  ImageDownloadManager.swift
//  PS_Ecommerce
//
//  Created by Pragati on 04/10/19.
//  Copyright © 2019 Pragati. All rights reserved.
//

import Foundation
import UIKit
typealias ImageDownloadHandler = (_ image: UIImage?, _ url: URL, _ error: Error?) -> Void
class ImageDownloadManager {

    lazy var imageDownloadQueue: OperationQueue = {
        var queue = OperationQueue()
        queue.name = "com.pragati.imageDownloadqueue"
        queue.qualityOfService = .userInteractive
        return queue
    }()
    let imageCache = NSCache<NSString, UIImage>()

    static let shared = ImageDownloadManager()
    private init () {}
    func loadImage(imageLink:String, indexPath: IndexPath?,handler: @escaping ImageDownloadHandler) {

        guard let url = URL(string: imageLink) else {
            return
        }
        if let cachedImage = imageCache.object(forKey: url.absoluteString as NSString) {
            /* check for the cached image for url, if YES then return the cached image */
          //  print("Return cached Image for \(url)")
            handler(cachedImage, url, nil)
        } else {
            /* check if there is a download task that is currently downloading the same image. */
            if let operations = (imageDownloadQueue.operations as? [LoadImageOperation])?.filter({$0.imageURL.absoluteString == url.absoluteString && $0.isFinished == false && $0.isExecuting == true }), let operation = operations.first {
               // print("Increase the priority for \(url)")
                operation.queuePriority = .veryHigh
            }else {
                /* create a new task to download the image.  */
               // print("Create a new task for \(url)")
                let operation = LoadImageOperation(url: url)
                if indexPath == nil {
                    operation.queuePriority = .high
                }
                operation.downloadHandler = { (image, url, error) in
                    if let newImage = image {
                        self.imageCache.setObject(newImage, forKey: url.absoluteString as NSString)
                    }
                    handler(image, url,  error)
                }
                imageDownloadQueue.addOperation(operation)

            }
        }
    }
    func slowdownLoading(imageLink:String) {
        if let operations = (imageDownloadQueue.operations as? [LoadImageOperation])?.filter({$0.imageURL.absoluteString == imageLink && $0.isFinished == false && $0.isExecuting == true }), let operation = operations.first {
           // print("Reduce the priority for \(imageLink)")
            operation.queuePriority = .low
        }

    }
    func cancelAll() {
        imageDownloadQueue.cancelAllOperations()
    }
}
