//
//  Interactor.swift
//  PS_Ecommerce
//
//  Created by Pragati Samant on 02/10/19.
//  Copyright © 2019 Pragati. All rights reserved.
//

import Foundation
class Query {
    var product_type:String?
    var brand:String?
    var tag:String?
    init(product_type:String?,brand:String?,tag:String?) {
        self.product_type = product_type
        self.brand = brand
        self.tag = tag
    }
}

class Interactor {
    func loadProduct(query:Query?) {
      //  RequestHandler().myRequest(params: query, <#T##completion: ((_?, Error?) -> ())?##((_?, Error?) -> ())?##(_?, Error?) -> ()#>)
    }
  
}
