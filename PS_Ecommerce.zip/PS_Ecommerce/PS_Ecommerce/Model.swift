//
//  Model.swift
//  PS_Ecommerce
//
//  Created by Pragati Samant on 02/10/19.
//  Copyright © 2019 Pragati. All rights reserved.
//

import Foundation

var productList:[Product] = []

class Product:Codable {
    let id: Int?
    let brand, name, price: String?
    let priceSign, currency: String?
    let imageLink: String?
    let productLink: String?
    let websiteLink: String?
    let welcomeDescription: String?
    let rating: Float?
    let category, productType: String?
    let tagList: [String]?
    let createdAt, updatedAt: String?
    let productAPIURL: String?
    let apiFeaturedImage: String?
    let productColors: [ProductColor]?
    
    init(id: Int, brand: String, name: String, price: String, priceSign: String?, currency: String?, imageLink: String, productLink: String, websiteLink: String, welcomeDescription: String, rating: Float?, category: String, productType: String, tagList: [String]?, createdAt: String, updatedAt: String, productAPIURL: String, apiFeaturedImage: String, productColors: [ProductColor]) {
        self.id = id
        self.brand = brand
        self.name = name
        self.price = price
        self.priceSign = priceSign
        self.currency = currency
        self.imageLink = imageLink
        self.productLink = productLink
        self.websiteLink = websiteLink
        self.welcomeDescription = welcomeDescription
        self.rating = rating
        self.category = category
        self.productType = productType
        self.tagList = tagList
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.productAPIURL = productAPIURL
        self.apiFeaturedImage = apiFeaturedImage
        self.productColors = productColors
    }
    enum CodingKeys: String, CodingKey {
        case id, brand, name, price
        case priceSign = "price_sign"
        case currency
        case imageLink = "image_link"
        case productLink = "product_link"
        case websiteLink = "website_link"
        case welcomeDescription = "description"
        case rating, category
        case productType = "product_type"
        case tagList = "tag_list"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
        case productAPIURL = "product_api_url"
        case apiFeaturedImage = "api_featured_image"
        case productColors = "product_colors"
    }
}

// MARK: - ProductColor
class ProductColor:Codable {
    let hexValue, colourName: String?
    
    init(hexValue: String, colourName: String) {
        self.hexValue = hexValue
        self.colourName = colourName
    }
    enum CodingKeys: String, CodingKey {
        case hexValue = "hex_value"
        case colourName = "colour_name"
    }
}

struct ProductType {
    var title:String
    var key:String
}
