//
//  DetailViewController.swift
//  PS_Ecommerce
//
//  Created by Pragati Samant on 02/10/19.
//  Copyright © 2019 Pragati. All rights reserved.
//

import UIKit
import WebKit
class ColorCell :UICollectionViewCell {

    @IBOutlet weak var colorButton: UIButton!
    @IBOutlet weak var colorLabel: UILabel!
    override func preferredLayoutAttributesFitting(_ layoutAttributes: UICollectionViewLayoutAttributes) -> UICollectionViewLayoutAttributes {
        setNeedsLayout()
        layoutIfNeeded()
        let size = contentView.systemLayoutSizeFitting(layoutAttributes.size)
        var frame = layoutAttributes.frame
        frame.size.width = ceil(size.width)
        layoutAttributes.frame = frame
        return layoutAttributes
    }
}
class ProductDetailViewController: UIViewController,UICollectionViewDataSource {
 @IBOutlet weak var productImageView: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var brand: UILabel!
    @IBOutlet weak var buyNow: UIButton!
    @IBOutlet weak var websiteLink: UIButton!
    @IBOutlet weak var detailDescriptionLabel: UILabel!

    @IBOutlet weak var colorCollectionView: UICollectionView!

    @IBOutlet weak var colorsHeightConstraint: NSLayoutConstraint!
    var detailItem: Product!
    @IBAction func showWebsite(_ sender: Any) {
        openProductWebsite()
    }
    class func instatantiate(product:Product) -> ProductDetailViewController {
        let productDetailVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProductDetail") as!  ProductDetailViewController
        productDetailVC.detailItem = product
        return productDetailVC
    }
    override func viewDidLoad() {
        super.viewDidLoad()
         self.title = "Product Details"
        // Do any additional setup after loading the view.
      //      detailItem = try? JSONDecoder().decode(Product.self, from: testjson2.data(using: String.Encoding.utf8)!)
        configureView()
        configureCollectionViewLayout()
    }
    override func viewDidAppear(_ animated: Bool) {
        colorCollectionView.reloadData()
        if (detailItem!.productColors!.count == 0) {
            self.colorsHeightConstraint.constant = 0
            self.view.setNeedsLayout()
        }
    }
    func configureView() {
        // Update the user interface for the detail item.

        name.text = detailItem.name ?? ""
        price.text = "Price: " + (detailItem.priceSign ?? "") + " " + (detailItem.price ?? "")
        brand.text = "Brand: " + (detailItem.brand ?? "")
        buyNow.setTitle("Buy Now", for: UIControl.State.normal)
        let prefix = "Description:"
        let descriptionText = prefix + (detailItem.welcomeDescription ?? "")
        detailDescriptionLabel.attributedText = Utils.getAttributedString(searchTerm:prefix , initialText: descriptionText)
        ImageDownloadManager.shared.loadImage(imageLink: detailItem.imageLink!, indexPath: nil) { [unowned self](image, url, error) in
            DispatchQueue.main.async {
                  self.productImageView.image = image
            }
        }

    }

    override func viewDidLayoutSubviews() {
      // self.colorCollectionView.reloadData()
    }
  
    func openProductWebsite() {
        let website = ProductWebsiteViewController.instantiate(productLink: detailItem!.productLink!)
        self.navigationController?.pushViewController(website, animated: true)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return detailItem!.productColors!.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! ColorCell
        let color = detailItem!.productColors![indexPath.item]
        cell.colorButton.backgroundColor = UIColor(hex:  color.hexValue!)
        cell.colorLabel.text = color.colourName ?? "No Color"
        adjustCollectionView()
        return cell
    }
    func adjustCollectionView() {
        let height = self.colorCollectionView.collectionViewLayout.collectionViewContentSize.height
        self.colorsHeightConstraint.constant = height
        self.view.setNeedsLayout()
    }
    func configureCollectionViewLayout() {
        let margin: CGFloat = 8
        if let flowLayout = colorCollectionView.collectionViewLayout as? UICollectionViewFlowLayout{
            flowLayout.minimumInteritemSpacing = margin
            flowLayout.minimumLineSpacing = margin
            flowLayout.estimatedItemSize = CGSize(width: 1000, height: 40)
        }
    }

}

