//
//  MasterViewController.swift
//  PS_Ecommerce
//
//  Created by Pragati Samant on 02/10/19.
//  Copyright © 2019 Pragati. All rights reserved.
//

import UIKit
class ProductListCell : UICollectionViewCell {
    @IBOutlet weak var productImageView: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var brand: UILabel!
    var product:Product!

    func configure(_ product:Product) {
        self.product = product
        name.text = product.name
        price.text = (product.priceSign ?? "") + (product.price ?? "")
        brand.text = product.brand
        productImageView.image = nil
        self.layer.cornerRadius = 8.0
    }

    override func preferredLayoutAttributesFitting(_ layoutAttributes: UICollectionViewLayoutAttributes) -> UICollectionViewLayoutAttributes {
        setNeedsLayout()
        layoutIfNeeded()
        let size = contentView.systemLayoutSizeFitting(layoutAttributes.size)
        var frame = layoutAttributes.frame
        frame.size.height = ceil(size.height)
        layoutAttributes.frame = frame
        return layoutAttributes
    }
}

class ProductListViewController: UICollectionViewController {


    var productType:ProductType!
    var productList : [Product]?
    var req:RequestHandler<[Product]>!

    class func instatntiate(productType:ProductType) -> ProductListViewController {
        let productListVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProductList") as! ProductListViewController
        productListVC.productType = productType
        return productListVC
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = productType.title
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadData()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        configureCollectionViewLayout()
    }
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! ProductListCell
        let product = productList![indexPath.row]
        cell.configure(product)
        loadImage(imageView: cell.productImageView, imageLink: product.imageLink!, indexPath: indexPath)
        return cell
    }
  
    func loadImage(imageView:UIImageView?, imageLink: String, indexPath: IndexPath){
        ImageDownloadManager.shared.loadImage(imageLink: imageLink, indexPath: indexPath) { (image, url, error) in
            DispatchQueue.main.async {
                imageView?.image = image
                imageView?.setNeedsDisplay()
            }
        }
    }
    override func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if let imageLink = productList?[indexPath.row].imageLink {
            ImageDownloadManager.shared.slowdownLoading(imageLink:imageLink)
        }
    }
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return productList?.count ?? 0
    }
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let productDetailVC = ProductDetailViewController.instatantiate(product:productList![indexPath.row])
        self.navigationController?.pushViewController(productDetailVC, animated: true)
    }

    func configureCollectionViewLayout() {
        var cellsPerRow = 0
        let margin: CGFloat = 10
        if (self.view.frame.width > 500) {cellsPerRow = 3}
        else {cellsPerRow = 2}

        if let flowLayout = collectionViewLayout as? UICollectionViewFlowLayout,
            let collectionView = collectionView {
            flowLayout.minimumInteritemSpacing = margin
            flowLayout.minimumLineSpacing = margin
            flowLayout.sectionInset = UIEdgeInsets(top: margin, left: margin, bottom: margin, right: margin)
            let marginsAndInsets = flowLayout.sectionInset.left + flowLayout.sectionInset.right + collectionView.safeAreaInsets.left + collectionView.safeAreaInsets.right + flowLayout.minimumInteritemSpacing * CGFloat(cellsPerRow - 1)
            let itemWidth = ((collectionView.bounds.size.width - marginsAndInsets) / CGFloat(cellsPerRow)).rounded(.down)

            flowLayout.estimatedItemSize = CGSize(width: itemWidth, height: itemWidth + 150)
            flowLayout.minimumInteritemSpacing = 10

        }
    }
    func loadData() {
        let query = Query(product_type: productType.key, brand: nil, tag: nil)
        req = RequestHandler<[Product]>(query:query)
        req.myRequest { [weak self] (products, error) in
           if(error != nil || products?.count == 0) {
            self?.showAlert(message: "No data found")
            }
            else {
                self?.productList = products
                self?.collectionView.reloadData()
            }
        }
    }
}


