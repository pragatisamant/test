//
//  MasterViewController.swift
//  PS_Ecommerce
//
//  Created by Pragati Samant on 02/10/19.
//  Copyright © 2019 Pragati. All rights reserved.
//

import UIKit

class ProductTypeViewController: UITableViewController {

    
    var productTypeList = Constants.productTypes


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       self.title = "What are you looking for?"
    }

    override func viewWillAppear(_ animated: Bool) {
   
        super.viewWillAppear(animated)
       
    }

   
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productTypeList.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel!.text = productTypeList[indexPath.row].title
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let productListVC = ProductListViewController.instatntiate(productType:productTypeList[indexPath.row])
        self.navigationController?.pushViewController(productListVC, animated: true)
    }


}

