//
//  ProductWebsiteViewController.swift
//  PS_Ecommerce
//
//  Created by Pragati Samant on 02/10/19.
//  Copyright © 2019 Pragati. All rights reserved.
//

import UIKit
import WebKit
class ProductWebsiteViewController: UIViewController {
    
    @IBOutlet weak var webView: WKWebView!
  
    var productLink:String! = "https://well.ca/products/covergirl-outlast-longwear-lipstick_105803.html"
    class func instantiate(productLink:String) -> ProductWebsiteViewController {
        let website = UIStoryboard(name: "Details", bundle: nil).instantiateViewController(withIdentifier: "ProductWebsite") as! ProductWebsiteViewController
        website.productLink = productLink
        return website
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        webView.load(URLRequest(url:URL(string: productLink!)!))
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
