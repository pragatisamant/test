//
//  RequestHandler.swift
//  RebelTestPragati
//
//  Created by Pragati Samant on 20/07/19.
//  Copyright © 2019 Pragati. All rights reserved.
//

import Foundation
//import Alamofire
//import AlamofireImage

class RequestHandler<U:Codable> {
    var query:Any?
    init(query:Any) {
        self.query = query
    }
 
    func testDecoder() {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        
      
        let jsonData =  testjson.data(using: .utf8)!
       // JSONDecoder().dataDecodingStrategy = .base64
        do {
        let product = try JSONDecoder().decode([Product].self, from: jsonData)
            print(product[0].name)
        }catch {
            print(error)
        }
        
    }
    var closure = { (response : Data?,completion : ((U?,Error?)->())?) in
        do {
            let u  = try JSONDecoder().decode(U.self, from: (response ?? nil)!)
            completion?(u,nil)
        }catch {
            print(String(bytes: response!, encoding: .utf8) as Any)
            completion?(nil,error)
        }
    }
    func myRequest(_ completion:((U?,Error?)->())?) {
      //  let parameters: Parameters? = nil //JSONAble.toDict(params)
//        let index = testjson.index(testjson.startIndex, offsetBy: 521)
//        let mySubstring = testjson[..<index]
//        print(mySubstring)
//         let data2  = testjson.data(using: String.Encoding.utf8)
//        self.closure(data2,completion)
//        return

        let url = createUrl(object: query!)
        DataRequestHandler.fetchData( url, completion:{ [weak self] data,error in
           // print(data)
         //   let data2  =  testjson.data(using: String.Encoding.utf8)
           // let json = try? JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableLeaves)
          //  print(json!)
            self?.closure(data,completion)
        })
    }
    func createUrl(object:Any) -> String {
        //http://makeup-api.herokuapp.com/api/v1/products.json
        var components = URLComponents()
        components.scheme = "http"
        components.host = "makeup-api.herokuapp.com"
        components.path = "/api/v1/products.json"
        let mirror = Mirror(reflecting: object)
        components.queryItems = [URLQueryItem]()
        for (_, attr) in mirror.children.enumerated() {
            
            if let property_name = attr.label,let value = attr.value as? String {
                components.queryItems?.append(URLQueryItem(name: property_name, value: value))
                //  print("\(mirror.description) \(index): \(property_name) = \(attr.value)")
            }
        }
        return components.url!.absoluteString
    }
}
class DataRequestHandler{
    static func fetchData(_ url:String,completion:@escaping (Data?,Error?)->()) {
        URLSession.shared.dataTask(with: URL(string:url)!,completionHandler:{ (data, response, error) in
            DispatchQueue.main.async {
                completion(data,error)
            }
        }).resume()
    }

}



