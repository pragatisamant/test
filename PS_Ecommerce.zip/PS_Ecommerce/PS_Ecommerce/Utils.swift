//
//  Utils.swift
//  PS_Ecommerce
//
//  Created by Pragati Samant on 02/10/19.
//  Copyright © 2019 Pragati. All rights reserved.
//

import Foundation
import UIKit



class LoadImageOperation: Operation {
    var downloadHandler: ImageDownloadHandler?
    var imageURL: URL!

    override var isAsynchronous: Bool {
        get {
            return  true
        }
    }
    private var _executing = false {
        willSet {
            willChangeValue(forKey: "isExecuting")
        }
        didSet {
            didChangeValue(forKey: "isExecuting")
        }
    }

    override var isExecuting: Bool {
        return _executing
    }

    private var _finished = false {
        willSet {
            willChangeValue(forKey: "isFinished")
        }

        didSet {
            didChangeValue(forKey: "isFinished")
        }
    }

    override var isFinished: Bool {
        return _finished
    }

    func executing(_ executing: Bool) {
        _executing = executing
    }

    func finish(_ finished: Bool) {
        _finished = finished
    }

    required init (url: URL) {
        self.imageURL = url
    }
    override func main() {
        guard isCancelled == false else {
            finish(true)
            return
        }
        self.executing(true)
        //Asynchronous logic (eg: n/w calls) with callback
        self.downloadImageFromUrl()
    }

    func downloadImageFromUrl() {
        let newSession = URLSession.shared
        let downloadTask = newSession.downloadTask(with: self.imageURL) { (location, response, error) in
            if let locationUrl = location, let data = try? Data(contentsOf: locationUrl){
                let image = UIImage(data: data)
                self.downloadHandler?(image,self.imageURL,error)
            }
            self.finish(true)
            self.executing(false)
        }
        downloadTask.resume()
    }

}
class Utils {
    class func getAttributedString(searchTerm:String, initialText:String) -> NSMutableAttributedString {
        let myAttribute = [ NSAttributedString.Key.font: UIFont.systemFont(ofSize: 17.0)]
        let myString = NSMutableAttributedString(string: initialText, attributes: myAttribute )
        let newRange = (initialText as NSString).range(of: searchTerm)
        myString.addAttribute(NSAttributedString.Key.font, value: UIFont.boldSystemFont(ofSize: 17), range: newRange)
        return myString
    }
    
}
extension UIColor {
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")

        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }

    convenience init(hex: String) {
        let rgb = intFromHexString(hexStr: hex)
        self.init(
            red: Int((rgb >> 16) & 0xFF),
            green: Int((rgb >> 8) & 0xFF),
            blue: Int(rgb & 0xFF)
        )
    }
}
func intFromHexString(hexStr: String) -> UInt32 {
    var hexInt: UInt32 = 0
    // Create scanner
    let scanner: Scanner = Scanner(string: hexStr)
    // Tell scanner to skip the # character
    scanner.charactersToBeSkipped = CharacterSet(charactersIn: "#")
    // Scan hex value
    scanner.scanHexInt32(&hexInt)
    return hexInt
}

extension UIViewController {
    func showAlert(message:String) {
        let alert = UIAlertController(title: nil, message:message , preferredStyle: .alert)
        self.present(alert, animated: true, completion: {
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 5, execute: {
                alert.dismiss(animated: true, completion: {
                    self.navigationController?.popViewController(animated: true)
                })
            })
        })
    }
}
